-- Run this SQL in Supabase SQL Editor. Create owner user in Authentication first,
-- then insert that user's UUID into public.admin_users. Never expose service_role key.
create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade
);
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null,
  price numeric(12,2) not null default 0 check (price >= 0),
  stock integer not null default 0 check (stock >= 0),
  image_url text,
  description text,
  created_at timestamptz not null default now()
);
alter table public.admin_users enable row level security;
alter table public.products enable row level security;
create policy "owner can read own admin record" on public.admin_users
for select to authenticated using (user_id = auth.uid());
create policy "public can view products" on public.products
for select to anon, authenticated using (true);
create policy "admins can insert products" on public.products
for insert to authenticated with check (exists(select 1 from public.admin_users a where a.user_id=auth.uid()));
create policy "admins can update products" on public.products
for update to authenticated using (exists(select 1 from public.admin_users a where a.user_id=auth.uid()))
with check (exists(select 1 from public.admin_users a where a.user_id=auth.uid()));
create policy "admins can delete products" on public.products
for delete to authenticated using (exists(select 1 from public.admin_users a where a.user_id=auth.uid()));
-- After creating your owner user in Supabase Auth, run:
-- insert into public.admin_users(user_id) values ('YOUR-AUTH-USER-UUID');
