# AVRONE — GitHub Pages edition

This is a static GitHub Pages storefront converted from the supplied Shopify Liquid theme. GitHub Pages cannot execute Shopify Liquid, Shopify checkout, or Shopify admin. This edition uses HTML/CSS/JavaScript and includes an optional Supabase-backed owner console.

## Publish on GitHub Pages
1. Extract this ZIP.
2. Upload all files and folders to the root of your GitHub repository (not inside an extra nested folder).
3. Commit to the `main` branch.
4. GitHub → Settings → Pages → Build and deployment → Deploy from a branch → `main` → `/ (root)` → Save.
5. Wait for the Pages deployment. Open the URL shown in Settings → Pages.

## Admin panel security setup (required for real owner-only access)
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Supabase Authentication, create your owner account.
4. Copy the owner's Auth user UUID and run:
   `insert into public.admin_users(user_id) values ('YOUR-AUTH-USER-UUID');`
5. Copy Project URL and anon/public key into `SB_URL` and `SB_ANON` in `assets/admin.js`, and into `SUPABASE_URL` and `SUPABASE_ANON_KEY` in `assets/app.js`.
6. In Supabase Auth URL configuration, add your GitHub Pages URL to Site URL and Redirect URLs.
7. Open `/admin/login.html` and sign in. The owner dashboard is not linked in customer navigation. The URL is not a secret; access is protected by Supabase Auth plus database Row Level Security.
8. Do not put a Supabase service-role key in frontend code.

## Product catalogue
The homepage currently includes four sample catalogue entries so the layout can be previewed. Those are placeholders, not real inventory. For persistent catalogue management across devices, connect Supabase as described above. This starter's public storefront currently uses browser local storage for the sample catalogue; wire the public product query to Supabase before publishing your managed catalogue.

## Checkout and orders
The cart is a front-end demonstration only. No payment is collected and no order is created. Before accepting real orders, integrate an approved payment gateway (for India, e.g. Razorpay/Shopify checkout subject to merchant approval), verify payment server-side using a backend/edge function and signed webhooks, and store orders securely. Never trust client-side payment status. The Track Order links go to the supplied Shopify account URL.

## Before launch
- Replace sample products and imagery with your real products.
- Replace `YOUR-SUPPORT-EMAIL@example.com` in `contact.html`.
- Write accurate shipping, returns, privacy and terms policies.
- Connect a payment provider, server-side order verification, email delivery and tracking workflow.
- Configure a custom domain only after DNS is ready.

## Files
- `index.html`: customer storefront
- `assets/style.css`, `assets/app.js`: storefront styles and interactions
- `admin/login.html`, `admin/index.html`: owner login/dashboard
- `assets/admin.js`: Supabase Auth and product CRUD
- `supabase/schema.sql`: database schema and RLS policies
